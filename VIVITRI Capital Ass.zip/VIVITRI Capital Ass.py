#!/usr/bin/env python
# coding: utf-8

# ### Write a program to compute the frequency of the words from the input. The output should output after sorting the key alphanumerically.

# In[2]:


import operator
word = input("Type in: ")
fre = {}
for i in word.split(' '):
    if i.isalpha():
        if i not in fre:
            fre[i] = 1
        elif i in fre:
            fre[i] = fre[i] + 1
    else:
        pass
sorted_fre = sorted(fre.items(), key = operator.itemgetter(0))
print(sorted_fre)
for i in sorted_fre:
    print(i[0], i[1])


# ### A website requires the users to input username and password to register. Write a program to check the validity of password input by users.

# In[8]:


import re
c = input("Input your password")
L = True
while L:  
    if (len(c)<6 or len(c)>12):
        break
    elif not re.search("[a-z]",c):
        break
    elif not re.search("[0-9]",c):
        break
    elif not re.search("[A-Z]",c):
        break
    elif not re.search("[$#@]",c):
        break
    elif re.search("\s",c):
        break
    else:
        print("Valid Password")
        x=False
        break

if L:
    print("Not a Valid Password")


# ### Write a program which takes 2 digits, X,Y as input and generates a 2-dimensional array. Theelement value in the i-th row and j-th column of the array should be i*j.

# In[13]:


Row_no = int(input("Input number of rows: "))
Columns_no = int(input("Input number of columns: "))
multilist = [[0 for Columns_no in range(Columns_no)] for Row_no in range(Row_no)]
for Row_no in range(Row_no):
    for Columns_no in range(Columns_no):
        multilist[Row_no][Columns_no]= Row_no*Columns_no
print(multilist)


# ### We will take a string of words from the user along with an integer k. We will find all words whoselength is greater than k. 

# In[14]:


def string_k(k, str):
    string = []
    text = str.split(" ")
    for x in text:
         if len(x) > k:
                 string.append(x)
    return string
k = 6
str ="Madhan is a Software Developer"
print(string_k(k, str))


# ##  Convert a String to camelCase in Python (Without using any string functions[capitalize()..etc], Use ASCII Values)

# In[1]:


def camelcase(list_words):  
    converted = "".join(word[0].upper() + word[1:].lower() for word in list_words)  
    return converted[0].lower() + converted[1:]  
  
words = ["Hello","world"]  
print(camelcase(words))  


# ### Find uncommon words from two string

# In[15]:


C1=input("Enter first string:")
C2=input("Enter second string:")
count = {}
for word in C1.split():
    count[word] = count.get(word, 0) + 1
for word in C2.split():
    count[word] = count.get(word, 0) + 1
uncommonWords =  [word for word in count if count[word] == 1]
print(" uncommon words  are ", uncommonWords)


# ### 7. Pattern Printing:

# In[7]:


rows = 6
for i in range(0, rows):
    for j in range(rows - 1, i, -1):
        print(j, '', end='')
    for l in range(i):
        print('    ', end='')
    for k in range(i + 1, rows):
        print(k, '', end='')
    print('\n')


# In[8]:


row = 4
for i in range(row,0,-1):
    for j in range(1,i+1):
        if(j+1==i+1):
            print(j,end=" ")
            break
        else:  
            print(j,"*",end=" ")
    print()   


# ### 9. Pattern Printing:

# In[9]:


rows = 6
for i in range(0, rows):
    for j in range(0, i + 1):
        print("*", end=' ')
    print(" ")

print(" ")

for i in range(rows + 1, 0, -1):
    for j in range(0, i - 1):
        print("*", end=' ')
    print(" ")               


# In[ ]:




